var app = angular.module('customerRecord', ['ngRoute', 'ngMessages']);

app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/', {
        templateUrl: 'views/login.html',
        controller: 'loginCtrl',
        controllerAs: 'vm'
      }).
      when('/customerRecords', {
        templateUrl: 'views/customerRecords.html',
        controller: 'customerRecordsCtrl',
        controllerAs: 'vm'
      }).
      when('/editCustomer', {
        templateUrl: 'views/customerDetail.html',
        controller: 'editCustomerCtrl',
        controllerAs: 'vm'
      }).
      when('/editCustomer/:customerId', {
        templateUrl: 'views/customerDetail.html',
        controller: 'editCustomerCtrl',
        controllerAs: 'vm'
      }).
      otherwise({
        redirectTo: '/customerRecords'
      });
  }]);

app.controller('indexController', ['$scope', '$rootScope', function($scope, $rootScope){
	$rootScope.showEmployeeListNavLinks  = false;
}]);

app.controller('loginCtrl', ['$scope', '$rootScope', '$location', function($scope, $rootScope, $location){
	var vm = this;

	$rootScope.showEmployeeListNavLinks = false;
	vm.showLoginValErrMsg = false;
	vm.login= function(isValid){
		if(vm.userName && vm.password){
			$location.path('customerRecords');
		}
		vm.showLoginValErrMsg = true;
	};
}]);


app.controller('customerRecordsCtrl', ['$scope', '$rootScope', 'customerRecordsService', function($scope, $rootScope, customerRecordsService){
	var vm = this;
	$rootScope.showEmployeeListNavLinks = true;

	vm.customers = customerRecordsService.getCustomers();
	vm.deleteCustomer = function(customerId){
		vm.customers = customerRecordsService.deleteCustomer(customerId);
	};
}]);

app.controller('editCustomerCtrl', ['$scope', '$rootScope', 'customerRecordsService', '$routeParams', '$location', function($scope, $rootScope, customerRecordsService, $routeParams, $location){
	var vm = this;
	$rootScope.showEmployeeListNavLinks = true;
	vm.customer = {
		firstName: '',
		lastName: '',
		phoneNumber: '',
		address: ''
	};
	var customerId = $routeParams.customerId;
	vm.customer = customerId ? customerRecordsService.fetchCustomer(customerId) : vm.customer;
	vm.saveCustomer = function(isValid){
		if(isValid){
			if (vm.customer.id) {
				customerRecordsService.editCustomer(vm.customer);
			} else{
				customerRecordsService.addCustomer(vm.customer);
			}
			$location.path('customerRecords');
		}else{
			return false;
		}
		
	};
}]);

app.service('customerRecordsService', function(){
	this.getCustomers = function(){

		var customers = JSON.parse(localStorage.getItem('customerRecords')) || [];
		if(!customers.length){
			customers = [{'id': 1, 'email': 'abc@abc.com', 'firstName': 'John', 'lastName': 'George', 'phoneNumber': 1234567890, 'address': '100 South pkwy Richardson Tx'},
			{'id': 2, 'email': 'abc@abc.com', 'firstName': 'John', 'lastName': 'George', 'phoneNumber': 1234567890, 'address': '100 South pkwy Richardson Tx'},
			{'id': 3, 'email': 'abc@abc.com', 'firstName': 'John', 'lastName': 'George', 'phoneNumber': 1234567890, 'address': '100 South pkwy Richardson Tx'}
			];
			localStorage.setItem('customerRecords', JSON.stringify(customers));
		}
		return customers;
	};

	this.addCustomer = function(customer){
		var customers = JSON.parse(localStorage.getItem('customerRecords'))|| [];
		customer.id = customers.length + 1;
		customers.push(customer);
		localStorage.setItem('customerRecords', JSON.stringify(customers));
	};

	this.fetchCustomer = function(customerId){
		var customers = JSON.parse(localStorage.getItem('customerRecords'))|| [];
		var customer = {};
		for (var i = 0; i < customers.length; i++) {
			var cust = customers[i];
			if(cust.id == customerId){
				customer = customers[i];
				break;
			}
		}
		return customer;
	};

	this.editCustomer = function(customer){
		var customers = JSON.parse(localStorage.getItem('customerRecords'))|| [];
		for (var i = 0; i < customers.length; i++) {
			if(customers[i].id == customer.id){
			   customers[i] = customer;
			}
		}
		localStorage.setItem('customerRecords', JSON.stringify(customers));
	};

	this.deleteCustomer = function(customerId){
		var customers = JSON.parse(localStorage.getItem('customerRecords'))|| [];
		for (var i = 0; i < customers.length; i++) {
			var cust = customers[i];
			if(cust.id == customerId){
				customers.splice(i, 1);
			}
		}
		localStorage.setItem('customerRecords', JSON.stringify(customers));
		return customers;
	};
});

app.directive('emailValidation', function(){
	return{
		restrict: 'A',
	    require: 'ngModel',
	    link: function (scope, elem, attrs, ctrl) {
	        if (!ctrl) {
	            return false;
	        }

	        function isValidEmail(value) {
	            if (!value) {
	                return false;
	            }
	            // Email Regex used by ASP.Net MVC
	            var regex = /^[\w-]+(\.[\w-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)*?\.[a-z]{2,6}|(\d{1,3}\.){3}\d{1,3})(:\d{4})?$/i;
	            return regex.exec(value) !== null;
	        }

	        scope.$watch(ctrl, function () {
	            ctrl.$validate();
	        });

	        ctrl.$validators.email = function (modelValue, viewValue) {
	            return isValidEmail(viewValue);
	        };
	    }
	};
});