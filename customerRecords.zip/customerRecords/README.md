# ECloud Customer Records

	This project stores the details about the customer in html5 session storage and has capabilities to add, edit and delete customers.

### Prerequisites

Make sure node npm is installed. If not installed, please find below link

```
https://nodejs.org/en/
```

### Installing

Please follow the below steps to install all the dependencise
1. This will install all the required npm modules like bower, grunt
```
npm install
```

2. Once bower is installed downloaded all the dependencies like angularjs, ng route, ng messages, bootstrap.

```
bower install
```


## Deployment

Once all the dependencies are installed. Execute the below command to start the server.

```
grunt
```

## Author

* **Rajashekar Reddy
